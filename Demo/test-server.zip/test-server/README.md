## test-server for socket.io-unity

This is a test-server written in javascript and run with node.js.

## Usage

```bash
# install the dependencies
npm install

# run the server
node index.js
```

Now use browser to open URL `http://localhost:3000/`, then input something to interact with server.

To test socket.io-unity, use socket.io code to access URL `http://localhost:3000`
